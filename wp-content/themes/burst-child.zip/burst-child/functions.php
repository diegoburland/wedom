<?php

if(!function_exists('burst_mikado_child_theme_enqueue_scripts')) {
	/*** Child Theme Function  ***/

	function burst_mikado_child_theme_enqueue_scripts() {

		$parent_style = 'burst-mikado-default-style';

		wp_register_style('childstyle', get_stylesheet_directory_uri() . '/style.css', array( $parent_style ));
		wp_enqueue_style('childstyle');
	}

	add_action('wp_enqueue_scripts', 'burst_mikado_child_theme_enqueue_scripts', 11);
}