<?php

if ( ! function_exists( 'mikado_core_register_widgets' ) ) {
	function mikado_core_register_widgets() {

		if(mikado_core_is_installed('theme')) {
			register_widget('BurstMikadoCallToAction');
			register_widget('BurstMikadoLatestPostsMenu');
			register_widget('BurstMikadoLatestPosts');
			register_widget('BurstMikadoStickySidebar');

			if (mikado_core_is_installed('woocommerce')) {
				register_widget('BurstMikadoWoocommerceDropdownCart');
			}
		}
	}
	
	add_action( 'widgets_init', 'mikado_core_register_widgets' );
}