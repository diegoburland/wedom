<?php

require_once 'const.php';
require_once MIKADO_CORE_ABS_PATH . '/helpers.php';
//load lib
require_once MIKADO_CORE_ABS_PATH . '/lib/post-type-interface.php';
require_once MIKADO_CORE_ABS_PATH . '/lib/shortcode-interface.php';

//load post-post-types
require_once MIKADO_CORE_ABS_PATH . '/post-types/portfolio/portfolio-register.php';
require_once MIKADO_CORE_ABS_PATH . '/post-types/portfolio/shortcodes/portfolio-list.php';
require_once MIKADO_CORE_ABS_PATH . '/post-types/portfolio/shortcodes/portfolio-slider.php';
require_once MIKADO_CORE_ABS_PATH . '/post-types/testimonials/testimonials-register.php';
require_once MIKADO_CORE_ABS_PATH . '/post-types/testimonials/shortcodes/testimonials.php';
require_once MIKADO_CORE_ABS_PATH . '/post-types/carousels/carousel-register.php';
require_once MIKADO_CORE_ABS_PATH . '/post-types/carousels/shortcodes/carousel.php';
require_once MIKADO_CORE_ABS_PATH . '/post-types/slider/slider-register.php';
require_once MIKADO_CORE_ABS_PATH . '/post-types/slider/tax-custom-fields.php';
require_once MIKADO_CORE_ABS_PATH . '/post-types/slider/shortcodes/slider.php';
require_once MIKADO_CORE_ABS_PATH . '/post-types/masonry-gallery/masonry-gallery-register.php';
require_once MIKADO_CORE_ABS_PATH . '/post-types/masonry-gallery/shortcodes/masonry-gallery.php';
require_once MIKADO_CORE_ABS_PATH . '/post-types/post-types-register.php'; //this has to be loaded last
require_once MIKADO_CORE_ABS_PATH . '/import/mkd-import.php';
require_once MIKADO_CORE_ABS_PATH . '/modules/mkd-seo.php';
require_once MIKADO_CORE_ABS_PATH . '/modules/mkd-like.php';
require_once MIKADO_CORE_ABS_PATH . '/modules/shortcodes/shortcodes.php';

//load shortcodes inteface
require_once MIKADO_CORE_ABS_PATH . '/lib/shortcode-loader.php';

//load widgets
require_once MIKADO_CORE_ABS_PATH . '/modules/widgets/helper.php';